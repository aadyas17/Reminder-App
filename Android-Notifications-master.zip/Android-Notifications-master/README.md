# Android-Notifications
Android Notifications App for Basic, Heads-Up and Expandable Notifications.

# Tools Used
- Andriod Studio
- Java
